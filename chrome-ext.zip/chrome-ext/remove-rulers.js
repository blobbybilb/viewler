try {
  document.getElementById("horizontal-ruler").remove();
  document.getElementById("vertical-ruler").remove();
} catch (_) {
  // ignore
}
